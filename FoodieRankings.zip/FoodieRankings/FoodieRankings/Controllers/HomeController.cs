﻿using FoodieRankings.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace FoodieRankings.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            //how to make an array of integers in C#
            //int[] nums = new int[5]; 
            //nums[0] = 234; and etc
            //OR
            //int[] nums= {23,12,23,45,65} (same as above)

            //how to make a list of strings
            //List<string> restaurantList = new List<string>();

            //foreach(RestaurantRankings r in RestaurantRankings.GetRestaurants())
            //{
            //$ is a string interpolation

            //restaurantList.Add($"#{r.Ranking}: {r.Name} - {r.Address}");
            //restaurantList.Add(string.Format("#{0}: {1} - {2}", r.Ranking, r.Name, r.Address));
            //restaurantList.Add("#" + r.Ranking + ": " + r.Name + " - " + r.Address);
            //}
            List<string> restaurantList = new List<string>();

            foreach(RestaurantRankings r in RestaurantRankings.GetRestaurantRankings())
            {
                string? Plate = r.Plate ?? "It's all tasty!";
                restaurantList.Add($"#{r.Ranking}: {r.Name} - Address: {r.Address} - Favorite Plate: {Plate} - Phone: {r.Phone} - {r.Link}");
            }

            return View(restaurantList);
        }
        [HttpGet]
        public IActionResult SuggestionForm()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SuggestionForm(FormResponse formRes)
        {
            TempStorage.AddApplication(formRes);
            return View("Confirmation", formRes);
        }

        public IActionResult SuggestionList()
        {
            return View(TempStorage.Applications);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
