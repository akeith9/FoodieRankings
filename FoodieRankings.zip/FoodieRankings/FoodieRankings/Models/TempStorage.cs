﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FoodieRankings.Models
{
    public class TempStorage
    {
        private static List<FormResponse> applications = new List<FormResponse>();

        public static IEnumerable<FormResponse> Applications => applications;
        // "Applications => applications" shortcut for "Applications(blah) {applications = blah;}"

        public static void AddApplication(FormResponse application)
        {
            applications.Add(application);
        }
    }
}
