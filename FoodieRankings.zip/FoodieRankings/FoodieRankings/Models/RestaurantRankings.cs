﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FoodieRankings.Models
{
    public class RestaurantRankings
    {
        //putting a ? behind the int or string then it will become a nullable variable
        //have to make it nullable on all sides to be functional
        // two ?? after declaring the variable says put something x in instead if value is null
        // or you could put "= x;" after the public string to set the default value
        
        //Constructor in C#
        //public RestaurantRankings(int rank)
        //{
        //  Ranking = rank;
        //}

        [Required]
        public int Ranking { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public string? Plate { get; set; }
        public string Phone { get; set; }
        [Required]
        public string Link { get; set; } = "Coming Soon.";
        //static means that affects all the models that apply to it (also accessible to other models)
        public static RestaurantRankings[] GetRestaurantRankings()
        {
            RestaurantRankings r1 = new RestaurantRankings
            { 
                Ranking = 1,
                Name = "Zupas",
                Address = "408 W 2230 N",
                Plate = "BBQ PULLED PORK",
                Phone = "(801) 377-7687",
                Link = "https://cafezupas.com/"
            };

            RestaurantRankings r2 = new RestaurantRankings
            {
                Ranking = 2,
                Name = "Mo Bettah's",
                Address = "1385 S State St, Orem, UT",
                Plate = "Pulehu Chicken Plate",
                Phone = "(801) 960-4616",
                Link = "https://mobettahs.com/"
            };

            RestaurantRankings r3 = new RestaurantRankings
            {
                Ranking = 3,
                Name = "Se Llama Peru",
                Address = "368 W Center St, Provo, UT",
                Plate = "Lomo Saltado",
                Phone = "(801) 375-0275"
            };

            RestaurantRankings r4 = new RestaurantRankings
            {
                Ranking = 4,
                Name = "Cafe Rio",
                Address = "2244 N University Pkwy, Provo, UT",
                Plate = "Enchilada",
                Phone = "(801) 375-5133",
                Link = "https://www.caferio.com/"
            };

            RestaurantRankings r5 = new RestaurantRankings
            {
                Ranking = 5,
                Name = "Blaze Pizza",
                Address = "1350 S State St, Orem, UT",
                Phone = "(801) 528-9501",
                Link = "https://www.blazepizza.com/"
            };

            return new RestaurantRankings[] { r1, r2, r3, r4, r5};
        }
    }
}
