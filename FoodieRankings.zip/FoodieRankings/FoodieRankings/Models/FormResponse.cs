﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FoodieRankings.Models
{
    public class FormResponse
    {
        [Required]
        public string Name { get; set; }
        [Required]
        public string RestaurantName { get; set; }
        [Required]
        public string Dish { get; set; }
        [Required]
        [RegularExpression(^\(\d{3}\) \d{3}-\d{ 4}$)]
        public string Phone { get; set; }
    }
}
